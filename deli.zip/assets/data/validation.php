<?php
if ($_POST["pass"] == "dasin") {
	echo 1;
} else {
	echo 0;
}

?>