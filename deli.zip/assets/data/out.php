<?php
header('Content-Type: application/json;charset=utf-8');
echo stripslashes(file_get_contents("menu.json"))

?>